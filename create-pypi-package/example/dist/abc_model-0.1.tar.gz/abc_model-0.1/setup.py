from setuptools import setup

setup(
    name='abc_model',
    version="0.1",
    description="First demo pack to uplod in pypi",
    packages=["abc_model"],
    author="pavi",
    author_email="pavi@gmail.com",
    zip_safe=False

)