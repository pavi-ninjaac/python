from abc_pac import add
a = add()
a.addition(6,7)