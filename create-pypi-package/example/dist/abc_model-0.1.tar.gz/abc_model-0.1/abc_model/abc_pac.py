import math

class add:
    def __init__(self) -> None:
        pass
    def addition(self,a ,b):
        print(a+b)
        